// src/pages/Dashboard.js
import React from "react";
import { Bar, Doughnut } from "react-chartjs-2";

const Dashboard = () => {
  const barData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [
      {
        label: "Expenses",
        data: [500, 400, 300, 450, 600, 700],
        backgroundColor: "rgba(75, 192, 192, 0.6)",
      },
    ],
  };

  const pieData = {
    labels: ["Food", "Transport", "Shopping", "Entertainment"],
    datasets: [
      {
        data: [300, 200, 100, 150],
        backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0"],
      },
    ],
  };

  return (
    <div className="container mt-4">
      <h1>Dashboard</h1>
      <div className="row">
        <div className="col-md-6">
          <div className="card p-3">
            <Bar data={barData} />
          </div>
        </div>
        <div className="col-md-6">
          <div className="card p-3">
            <Doughnut data={pieData} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
