import React from 'react'

import { Helmet } from 'react-helmet'

import Navbar from './components/navbar'
import Hero from './components/hero'
//import Features1 from '../components/features1'
//import CTA from '../components/cta'
//import Features2 from '../components/features2'
import Steps from './components/Steps'
//import Testimonial from '../components/testimonial'
import Contact from './pages/contact'
import Footer from './components/Footer'
import './App.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Spotless Hungry Crocodile</title>
      </Helmet>
      <Navbar></Navbar>
      <Hero></Hero>
      <Steps></Steps>
      <Contact></Contact>
      <Footer></Footer>
    </div>
  )
}

export default Home
