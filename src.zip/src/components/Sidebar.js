// src/components/Sidebar.js
import React from "react";
import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <div className="d-flex flex-column bg-light vh-100 p-3">
      <h4>MoneyMate</h4>
      <ul className="nav flex-column">
        <li className="nav-item">
          <Link className="nav-link" to="/dashboard">
            Dashboard
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/add-expense">
            Add Expense
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/budgets">
            Budgets
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/insights">
            Insights
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/settings">
            Settings
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
